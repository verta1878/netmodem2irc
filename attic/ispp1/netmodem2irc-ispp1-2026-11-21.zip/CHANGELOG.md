# Changelog

## 2026-11-21 — byte (InnoIRC561 ISPP + installers)

### InnoIRC561 — ISPP preprocessor
- `InnoIRC561/out/ISPP.dll` + `ISPPBuiltins.iss`: InnoIRC561 now has Inno's preprocessor, so `#define` scripts compile
  (they stopped with "To install ISPP, reinstall Inno Setup"). Source changes in `Projects/ISPP` (FPC only);
  `Version.inc`, `Int64em.pas`, `ISPP.res` renamed to the case the code uses (Linux builds without links).
  `InnoIRC561/tests/ispp-test.iss`. See `InnoIRC561/CHANGELOG.md`.

### Installer — Win98 fix where it belongs
- The 2026-11-20 `MinVersion=4.1,5.0` change was made in a copy at the repo root (`netmodem32.iss`, whose paths only
  work under `installer/`); that copy is now `attic/netmodem32.iss` and the change is in `installer/netmodem32.iss`.
- `installer/netfosdl.iss`: `MinVersion=4.1,5.0` too (it has the Win9x FOSSIL.VXD component, which `0,5.0` blocked);
  `LicenseFile=Docs\LICENSE.TXT` (was `..\docs\LICENSE.TXT`, which does not exist).
- Both keep their `#define`s and build with InnoIRC561 + ISPP; tested under Wine (Win2000 + Win98 mode): install,
  uninstall. Real Win98: open.
- `MD5SUMS.txt` / `SHA256SUMS.txt` regenerated for every file (were from 2026-09-04).

## 2026-11-20 — wrench (Cyclades + installer)

### Installer — Win98 enabled
- `installer/netmodem32.iss`: MinVersion changed from `0,5.0` to `4.1,5.0`
  — Win98/ME installs now allowed, matching the script's existing Win9x
  components (FOSSIL.VXD, IsWin9x check, SYSTEM.INI registration).
  Requires InnoIRC561 with byte's bug 3 fix (commit ab9787f).

### Cyclades — CD1400 baud rate tables added
- `fossil/cyclades/cd1400_regs.pas`: added 25 MHz (Rev G) and 60 MHz
  (Rev J) prescaler/clock-option lookup tables from byte's cyfossil.asm
  (verified against working hardware). Ready for Dell hardware test.

### InnoIRC561 bug impact audit
- `NETMODEM2IRC-INNO-AUDIT.md`: documents impact of byte's 6 InnoIRC561
  fixes (ab9787f + 48ffd5b) on both installer scripts. Key findings:
  LZMA crash, silent exit hang, and [Code] section breakage all affected
  netmodem32.iss; MinVersion change unlocks the fix.

## R5.3 — 2026-10-14

### VxD — NETMODEM.VXD hardened (N4 + N5)

Hardening means making the driver not crash when things go wrong.
Derk's original NETMODEM.ASM worked but had no guards — if a buffer
underflowed, a callback fired after cleanup, or a FIFO counter went
negative, the driver would corrupt memory or bluescreen.

- **SafeDec macro** — every `dec [counter]` in the driver (34 sites)
  now checks for zero before decrementing, so a FIFO counter can never
  go negative and wrap to 65535
- **Event callbacks** — the driver now notifies Win32 apps when modem
  status changes (CTS/DSR/DCD), instead of silently changing state
- **CTS/DSR default high** — BBS software expects these lines asserted
  on connect; the original code left them low, which made some BBS
  software think nobody was connected
- **Callback cleanup on close** — registered callbacks are cleared when
  the port closes, so Windows doesn't call into freed memory

None of it adds features. It makes the existing features not break
under real-world conditions.

Additionally:
- Compiled from source: JWasm v2.12pre + wlink 2.0, Linux native (no MASM/DDK/Wine)
- N5: ATI4-I7 info string stubs + Win32 comm event addressing
- 0 warnings, 0 errors, 0 TODOs remaining
- Final: 5,823 lines, 31,921 bytes (SHA256: 4efa68d821033030...)

### Engine — N3 features
- NM_Phonebook.pas (225L) — 100-slot virtual phonebook, CSV, AT&Z/ATDS
- NM_BlockList.pas (309L) — IP allow/block/forward, wildcard+CIDR, first-match-wins
- Config GUI tabs: phonebook, blocking, listserv
- IconLegend: status icon reference panel

### Tests
- 156 total (38 engine + 37 binary safety + 6 live + 25 multinode + 50 relay)

### Build
- VxD build system: driver/build/build_vxd.sh (7 JWasm DDK includes)
- Toolchain verified byte-exact on FOSSIL.VXD before use
## 2026-07-25 — licensing, docs audit, output layout

- **Licence split**: GPLv3 for revival work, GPLv2 retained for Dedrick
  Allen's original material. `LICENSE` is now GPLv3; `LICENSE-GPLv2`
  preserved; `LICENSES.md` added with the chain of title and open
  questions. No longer shareware.
- GPLv3 headers added to 68 source files (engine, engine/test, server,
  config, common, dos). Files under `driver/src/`, `history/`,
  `cpl/original_forms/`, `libs/synapse/` and `attic/` deliberately
  untouched. `driver/src/LICENSE-NOTICE.md` added.
- Stale GPLv2-only claims corrected in `THIRD_PARTY.md` and `AUTHORS`.
- **Docs audit**: `attic/docs/` removed — all 26 files were
  byte-identical shadow copies of live files in `docs/`. Root
  `netmodem2irc_CREDITS.md` removed; the attic copy is the retired one,
  as `attic/README.md` always said.
- `docs/README.md` added — index and status for all 46 docs.
- `docs/netmodem2irc_fossil_separation.md` added, then corrected by the
  maintainer. Both sides answer INT 14h; the real distinction is a
  **real UART** (DOS) versus an **emulated** one (virtual comport).
- **DOS settled as standalone with no network.** `netfosdl.exe` is a
  FTSC FOSSIL driver over a real UART — not part of netmodem, no `NM_*`
  units, no SEAM, no TCP. Must be a drop-in for X00 / BNU / ADF /
  NetFoss. DOS and i386 are independent platforms, not one pipeline.
- **Watt-32 removed.** `dos/stubs.asm` retired to `attic/watt32/`.
  The ten `_w32_*` externals in `dos/netmodem.pas` are to be deleted,
  not ported — FPC's i8086 `sockets` unit has no backend and `fcl-net`
  wraps `Sockets`/`WinSock2`/`Windows`, so neither works on DOS.
- `docs/netmodem2irc_watt32_cleanup_phases.md` added — 8 phases.
- `docs/netmodem2irc_synapse.md` added — the bundled library file by
  file, `NM_SynapseLink`, and its two tests. Records that
  `libs/synapse/smtpsend.pas` is a zero-byte placeholder and that
  `synaser.pas` is unused.
- `engine/NM_Debug.pas` added — central debug logging. Compiles to
  nothing without `-dNM_DEBUG`. Win32: `OutputDebugString` + file.
  DOS: file or stderr. Play/Stop runtime toggle and TDebugLineEvent
  callback implemented, inspired by Carl Gorringe's RIPtermJS debug log.
  Visual debug panel (TMemo) is the remaining GUI work.
- `ROADMAP.md` added — master roadmap across all three tracks, order of
  work, and the aggressive commenting standard codified.
- **Output layout**: `out/` split by target arch into `dos/`, `win32/`,
  `i386/`. `out/i386/` contents undecided.
- `InnoIRC561/`: source extracted to `src/` (498 files), tarball rebuilt
  without build artifacts (4.7M to 2.2M), original upstream tarball
  restored and renamed
  `innosetup-5.6.1-ORIGINAL-delphi-not-win98.tar.gz`, three superseded
  docs moved to `InnoIRC561/superseded/`, Phase 10 opened for the
  ISCmplr DLL-init AV.

## Current — full config GUI, global settings, installer

- ConfigMain: all 11 per-node fields + 25 global settings wired to GUI
  (5 tabbed pages: Comports, Server, Logging, Options, Features)
- NM_GlobalConfig: server-level settings (registry + NETCONFIG.CNF)
- NM_Listserv: BBS directory registration (designed by Dedrick, never finished)
- NM_AutoNews: periodic news broadcast (designed by Dedrick, never finished)
- Original NETMODEM.CPL (657KB, Delphi 5) preserved and shipped as-is
- Icons: 14 icons + 36 bitmaps extracted from original CPL
- Globe + splash bitmaps extracted from TForm1
- Inno Setup installer script (InnoIRC561/netmodem2irc.iss)
- build.sh: win32/tests/fossil/resources/clean targets
- 38/38 tests, 0 failures
- fpc264irc r3.1+

## M1 — engine integrated

- Engine: UART 16550, FOSSIL INT 14h, Telnet transport, AT commands,
  multinode manager, Synapse + named-pipe links, server bridge
- NM_Config: all 11 per-node ComportStruct fields, 14 baud rates
- NM_DefaultConfig: factory defaults, registry read/write
- NMVxD: driver interface with {$IFDEF WINDOWS} guards
- SEAM protocol: driver↔server framed binary protocol
- TSR skeleton: FOSSIL resident-program framework
- Win32 cross-compile from Linux
- DOS i8086 FOSSIL bridge (netfossl.exe, 179KB — superseded by netfosdl)
- 38 test programs covering all engine units

## M0 — initial recovery

- Recovered Dedrick Allen's original NetModem/32 source
- VxD driver (NETMODEM.ASM/INC/DEF) — experimental
- Original distributions preserved (net32_b4, netmdb15)
- Original CPL binary + 6 decompiled DFM forms
